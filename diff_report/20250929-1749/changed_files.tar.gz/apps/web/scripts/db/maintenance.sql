-- ANALYZE target
ANALYZE public.chunks;

-- опционально: вакуум
-- VACUUM (ANALYZE) public.chunks;
