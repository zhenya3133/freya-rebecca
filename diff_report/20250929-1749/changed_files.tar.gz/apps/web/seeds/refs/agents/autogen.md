---
title: "AutoGen"
type: "framework"
url: "https://microsoft.github.io/autogen/"
published_at: "2025-04-28"
tags: ["agents","autogen"]
---
Мульти-агентные паттерны, чатовые роли, инструменты, маршрутизация, мониторинг диалогов.
