---
title: "OpenAI Agents Overview"
type: "framework"
url: "https://platform.openai.com/docs/assistants/overview"
published_at: "2025-07-30"
tags: ["agents","openai","assistants"]
---
Короткий конспект: ключевые понятия, инструменты, режимы, best practices. 
