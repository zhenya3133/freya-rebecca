---
title: "LlamaIndex (Agentic RAG)"
type: "framework"
url: "https://docs.llamaindex.ai/"
published_at: "2025-07-05"
tags: ["rag","llamaindex","agents"]
---
Индексы, графы запросов, Router/QueryEngine, интеграции с векторными БД.
