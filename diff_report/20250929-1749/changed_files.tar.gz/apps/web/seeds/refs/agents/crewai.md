---
title: "CrewAI"
type: "framework"
url: "https://www.crewai.com/"
published_at: "2025-05-15"
tags: ["agents","crewai"]
---
Идея: роли и процессы, экипажи агентов, делегирование задач и валидация результатов.
