---
title: "LangGraph (Agents Orchestration)"
type: "framework"
url: "https://langchain-ai.github.io/langgraph/"
published_at: "2025-06-20"
tags: ["agents","orchestration","langgraph"]
---
Ключевые идеи: граф задач, контролируемые переходы, state, checkpointers, human-in-the-loop.
