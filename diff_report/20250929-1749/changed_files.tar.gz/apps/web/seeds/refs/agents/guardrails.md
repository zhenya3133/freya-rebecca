---
title: "Guardrails / Safety for Agents"
type: "guide"
url: "https://github.com/guardrails-ai/guardrails"
published_at: "2025-06-01"
tags: ["safety","guardrails","validation"]
---
Валидация схем (pydantic/jsonschema), запреты, безопасные вызовы инструментов, аудит.
