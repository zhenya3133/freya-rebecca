---
title: Prompts & Profiles
ns: rebecca/docs
kind: rebecca/docs
tags: [prompts, profiles]
owner: team-rebecca
ttl_days: 180
---

# Профили ответов

Поддерживаем: qa / json / code / list / spec. Жёсткие требования к форматам, без «воды» до/после.
