---
title: KB Curation Playbook
ns: rebecca/docs
kind: rebecca/docs
tags: [kb, curation, metadata]
owner: team-rebecca
ttl_days: 180
---

# Курирование БЗ

Именование ns/kind, TTL, заполнение metadata из YAML, дедуп по content_hash, чек-листы обновлений.
